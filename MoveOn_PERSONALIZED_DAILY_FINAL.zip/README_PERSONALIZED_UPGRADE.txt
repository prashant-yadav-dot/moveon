MoveOn — Personalized Daily Upgrade

Base project: MoveOn_FINAL_ALL_FEATURES_FIXED

What changed:
- Added shared daily-challenges.js engine.
- Daily challenges now use all four onboarding dimensions: mood, goal, support preference, and future feeling.
- Different onboarding combinations produce different challenge plans.
- Same user gets daily variation while staying aligned with their onboarding profile.
- Challenges page and Home page use the same personalized challenge engine, so they stay consistent.
- Home Today's healing challenge is no longer a generic fixed task.
- Challenge completion is saved using the personalized challenge ID and date.
- Existing Firebase/local fallback behavior is preserved.
- Existing MoveOn pages/features/design were kept intact.

Deployment:
Keep the existing Cloudflare Worker + assets structure and wrangler.jsonc.
