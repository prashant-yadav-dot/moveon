MOVEON — FINAL ALL-FEATURES PACKAGE

Repository root MUST contain:
  worker.js
  wrangler.jsonc
  Moveon/
  README.md (optional)

MoveOn/ contains all HTML/JS/assets/blog files.

Features fixed/added in this package:
- Ex Roleplay uses the main Worker route /api/ex-roleplay.
- Ex Roleplay frontend shows the real backend error instead of hiding it.
- Ex Roleplay keeps the chosen fictional character name and local conversation.
- Duplicate ex-roleplay-worker.js removed.
- Challenges are personalized from onboarding answers (mood, goal, support, future).
- Challenges keep Firebase progress and also have a local-device fallback.
- Emoji interactions have lightweight related Web Audio feedback sounds. No audio files or external sound host is required.
- All existing MoveOn pages and SEO blog files from the supplied package are preserved.

CLOUDFLARE
- Keep OPENAI_API_KEY as a Cloudflare Worker Secret.
- Do not put the API key into GitHub or HTML/JS.
- Deploy command: npx wrangler deploy
- Static files are served from ./Moveon.

TEST
Open:
https://moveon.shanydv001.workers.dev/ex-roleplay.html
Then send: hi

For onboarding/challenges:
Login -> onboarding -> choose answers -> Start Journey -> Challenges.
The challenge set should reflect those onboarding choices.

IMPORTANT
This ZIP has no extra outer folder. Upload the ZIP contents directly to the GitHub repository root.
