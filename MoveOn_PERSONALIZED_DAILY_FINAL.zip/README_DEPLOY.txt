MOVEON — FINAL EX ROLEPLAY DEPLOYMENT

This package is configured as one Cloudflare Worker with:
- Static website assets in ./Moveon
- Worker backend in ./worker.js
- POST /api/ex-roleplay for the AI chat
- Cloudflare secret OPENAI_API_KEY (do NOT put the key in GitHub)

IMPORTANT:
1. Upload the CONTENTS of this package to the ROOT of your GitHub repository.
2. Keep the Moveon folder name exactly as "Moveon".
3. Keep worker.js and wrangler.jsonc at repository ROOT.
4. In Cloudflare Build settings, Deploy command can remain: npx wrangler deploy
5. Root directory should be the repository root (not /Moveon).
6. Do NOT replace OPENAI_API_KEY with a normal variable or put its value in code.
7. After GitHub commit, Cloudflare should build/deploy automatically.
8. Test: https://YOUR-DOMAIN/ex-roleplay.html
9. Send a test message. The frontend calls /api/ex-roleplay on the same domain.

Do NOT deploy Moveon/ex-roleplay-worker.js as the main website Worker. It is retained only as reference/setup material; the actual API is already integrated into worker.js.
